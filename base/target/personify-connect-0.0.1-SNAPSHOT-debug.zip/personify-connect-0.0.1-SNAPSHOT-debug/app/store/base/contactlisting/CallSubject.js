
Ext.define('Personify.store.base.contactlisting.CallSubject', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.contactlisting.CallSubject'
    ]
});