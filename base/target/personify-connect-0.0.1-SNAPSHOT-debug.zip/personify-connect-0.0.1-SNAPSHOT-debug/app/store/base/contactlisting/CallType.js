
Ext.define('Personify.store.base.contactlisting.CallType', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.contactlisting.CallType'
    ]
});