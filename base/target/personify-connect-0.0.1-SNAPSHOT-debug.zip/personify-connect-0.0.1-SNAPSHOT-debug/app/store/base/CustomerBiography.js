Ext.define('Personify.store.base.CustomerBiography', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.CustomerBiography'
    ]
});