
Ext.define('Personify.store.base.Cart', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Cart'
    ]
});