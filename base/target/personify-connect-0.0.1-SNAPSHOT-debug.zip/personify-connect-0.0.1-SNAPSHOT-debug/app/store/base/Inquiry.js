Ext.define('Personify.store.base.Inquiry', {
    extend: 'Personify.base.Store'
});
