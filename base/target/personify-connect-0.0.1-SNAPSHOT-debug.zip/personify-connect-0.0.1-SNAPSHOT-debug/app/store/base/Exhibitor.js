Ext.define('Personify.store.base.Exhibitor', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.Exhibitor'
});