Ext.define('Personify.store.base.AddNewCustomerMeetingAgenda', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.CustomerMeetingAgenda'
    ]
});