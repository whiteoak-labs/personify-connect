Ext.define('Personify.store.base.calendar.Event', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.calendar.Event'
});