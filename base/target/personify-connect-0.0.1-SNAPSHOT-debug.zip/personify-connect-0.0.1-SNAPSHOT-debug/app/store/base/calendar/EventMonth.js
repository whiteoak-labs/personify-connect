Ext.define('Personify.store.base.calendar.EventMonth', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.calendar.EventMonth'
});
