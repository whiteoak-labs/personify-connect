Ext.define('Personify.store.base.SaveCustomerMeetingAgenda', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.CustomerMeetingAgenda'
    ]
});