
Ext.define('Personify.store.base.Material', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Material'
    ]
});