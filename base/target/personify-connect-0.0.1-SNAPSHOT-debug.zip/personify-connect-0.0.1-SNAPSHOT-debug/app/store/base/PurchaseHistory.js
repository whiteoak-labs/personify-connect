
Ext.define('Personify.store.base.PurchaseHistory', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.PurchaseHistory'
    ]
});