Ext.define('Personify.store.base.product.Product', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.product.Product'
});