
Ext.define('Personify.store.base.Country', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Country'
    ]
});