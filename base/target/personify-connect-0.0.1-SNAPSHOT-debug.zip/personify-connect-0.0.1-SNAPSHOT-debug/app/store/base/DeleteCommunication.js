Ext.define('Personify.store.base.DeleteCommunication', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Profile'
    ]
});