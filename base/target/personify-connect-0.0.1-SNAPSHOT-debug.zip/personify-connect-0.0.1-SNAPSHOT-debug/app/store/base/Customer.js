Ext.define('Personify.store.base.Customer', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Customer'
    ]
});