Ext.define('Personify.store.base.Staff', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Staff'
    ]
});