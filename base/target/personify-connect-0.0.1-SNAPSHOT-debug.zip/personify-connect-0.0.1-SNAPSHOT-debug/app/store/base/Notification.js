
Ext.define('Personify.store.base.Notification', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Notification'
    ]
});