
Ext.define('Personify.store.base.Contact', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.Contact'
});