Ext.define('Personify.store.base.SaveDeleteMeetingAgenda', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.CustomerMeetingAgenda'
    ]
});