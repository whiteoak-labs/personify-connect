Ext.define('Personify.store.base.ICalendar', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.ICalendar'
    ]
});