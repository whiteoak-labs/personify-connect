
Ext.define('Personify.store.base.Profile', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.Profile'
});