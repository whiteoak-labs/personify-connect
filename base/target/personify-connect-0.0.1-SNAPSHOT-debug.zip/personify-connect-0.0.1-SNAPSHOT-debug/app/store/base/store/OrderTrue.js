Ext.define('Personify.store.base.store.OrderTrue', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.store.OrderTrue'
});
