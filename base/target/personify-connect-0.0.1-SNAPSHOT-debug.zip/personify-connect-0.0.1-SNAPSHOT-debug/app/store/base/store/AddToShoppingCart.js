Ext.define('Personify.store.base.store.AddToShoppingCart', {
    extend: 'Personify.base.Store',
    
    requires: [
        'Personify.model.base.store.AddToShoppingCart'
    ]
});
