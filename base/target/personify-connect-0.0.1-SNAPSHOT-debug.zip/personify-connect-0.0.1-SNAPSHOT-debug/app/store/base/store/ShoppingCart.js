Ext.define('Personify.store.base.store.ShoppingCart', {
    extend: 'Personify.base.Store',
    
    requires: [
        'Personify.model.base.store.ShoppingCart'
    ]
});
