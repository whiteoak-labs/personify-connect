Ext.define('Personify.store.base.store.OrderFalse', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.store.OrderFalse',
    
    config: {
        model: 'Personify.model.base.store.OrderFalse'
        
    }
});
