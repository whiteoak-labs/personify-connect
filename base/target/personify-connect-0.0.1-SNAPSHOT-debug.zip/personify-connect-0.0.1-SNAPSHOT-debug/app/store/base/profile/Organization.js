Ext.define('Personify.store.base.profile.Organization', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.Organization'
});