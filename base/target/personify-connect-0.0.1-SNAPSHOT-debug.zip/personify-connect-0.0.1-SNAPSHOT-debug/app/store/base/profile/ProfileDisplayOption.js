Ext.define('Personify.store.base.profile.ProfileDisplayOption', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.ProfileDisplayOption',

    config: {
        model: 'Personify.model.base.profile.ProfileDisplayOption'
    }
});