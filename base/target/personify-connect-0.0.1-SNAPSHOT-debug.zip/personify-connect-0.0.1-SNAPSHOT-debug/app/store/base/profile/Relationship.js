Ext.define('Personify.store.base.profile.Relationship', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.relationship.RelationshipManagement'
    ]
});