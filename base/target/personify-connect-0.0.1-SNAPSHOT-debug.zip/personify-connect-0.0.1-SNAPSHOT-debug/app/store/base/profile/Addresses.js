Ext.define('Personify.store.base.profile.Addresses', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.Addresses'
});