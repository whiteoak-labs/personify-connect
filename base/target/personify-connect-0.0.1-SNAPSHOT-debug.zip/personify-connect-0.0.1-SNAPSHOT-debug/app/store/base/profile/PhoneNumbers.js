Ext.define('Personify.store.base.profile.PhoneNumbers', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.PhoneNumbers'
});