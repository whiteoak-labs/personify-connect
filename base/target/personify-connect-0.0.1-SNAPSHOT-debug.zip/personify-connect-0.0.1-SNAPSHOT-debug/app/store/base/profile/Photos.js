Ext.define('Personify.store.base.profile.Photos', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.Photos'
});