Ext.define('Personify.store.base.profile.Name', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.Name'
});