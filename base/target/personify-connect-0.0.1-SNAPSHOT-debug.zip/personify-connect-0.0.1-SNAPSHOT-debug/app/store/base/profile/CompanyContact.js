Ext.define('Personify.store.base.profile.CompanyContact', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.CompanyContact'
});