
Ext.define('Personify.store.base.profile.UpdateProfile', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.Profile'
});