Ext.define('Personify.store.base.profile.Geo', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.Geo'
});