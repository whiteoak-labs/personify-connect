Ext.define('Personify.store.base.profile.ContactTracking', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.contactlisting.ContactDetailManagement'
    ]
});