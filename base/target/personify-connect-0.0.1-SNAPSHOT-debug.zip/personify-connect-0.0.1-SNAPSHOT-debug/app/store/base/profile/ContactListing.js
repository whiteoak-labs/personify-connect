Ext.define('Personify.store.base.profile.ContactListing', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.contactlisting.ContactManagement'
    ]
});