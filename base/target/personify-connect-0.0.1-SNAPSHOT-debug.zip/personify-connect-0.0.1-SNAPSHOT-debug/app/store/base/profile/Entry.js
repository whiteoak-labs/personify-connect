Ext.define('Personify.store.base.profile.Entry', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.Entry'
});