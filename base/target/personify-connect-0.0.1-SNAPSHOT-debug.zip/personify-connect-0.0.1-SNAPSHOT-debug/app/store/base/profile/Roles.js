Ext.define('Personify.store.base.profile.Roles', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.Roles'
});