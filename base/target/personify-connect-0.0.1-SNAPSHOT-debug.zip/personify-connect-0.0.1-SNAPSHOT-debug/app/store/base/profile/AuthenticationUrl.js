Ext.define('Personify.store.base.profile.AuthenticationUrl', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.profile.AuthenticationUrl'
    ]
});
