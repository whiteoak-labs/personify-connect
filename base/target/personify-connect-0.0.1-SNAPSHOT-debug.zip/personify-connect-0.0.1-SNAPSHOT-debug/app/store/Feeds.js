Ext.define('Personify.store.Feeds', {
    extend: 'Personify.base.Store',
    
    config: {
        
    }
});
