Ext.define('Personify.store.ViewModules', {
	extend: 'Personify.base.Store',
	
	requires: [
	    'Personify.model.ViewModule'
	],
	
	config: {
		model: 'Personify.model.ViewModule'
	}
});
