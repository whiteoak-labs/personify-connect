Ext.define('Personify.store.offline.profile.Urls', {
    extend: 'Personify.store.base.profile.Urls',
    requires: 'Personify.model.jsonp.profile.Urls',
    config: {
        model: 'Personify.model.jsonp.profile.Urls'
    }
});