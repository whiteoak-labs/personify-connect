Ext.define('Personify.store.jsonp.profile.Entry', {
    extend: 'Personify.store.base.profile.Entry',
    requires: 'Personify.model.jsonp.profile.Entry',
    config: {
        model: 'Personify.model.jsonp.profile.Entry'
    }
});