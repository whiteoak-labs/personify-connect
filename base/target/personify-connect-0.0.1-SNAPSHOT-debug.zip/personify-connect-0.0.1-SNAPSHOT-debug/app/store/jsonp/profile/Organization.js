Ext.define('Personify.store.jsonp.profile.Organization', {
    extend: 'Personify.store.base.profile.Organization',
    requires: 'Personify.model.jsonp.profile.Organization',
    config: {
        model: 'Personify.model.jsonp.profile.Organization'
    }
});