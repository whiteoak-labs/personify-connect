Ext.define('Personify.store.jsonp.profile.Name', {
    extend: 'Personify.store.base.profile.Name',
    requires: 'Personify.model.jsonp.profile.Name',
    config: {
        model: 'Personify.model.jsonp.profile.Name'
    }
});