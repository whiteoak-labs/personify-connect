Ext.define('Personify.store.jsonp.profile.CompanyContact', {
    extend: 'Personify.store.base.profile.CompanyContact',
    requires: 'Personify.model.jsonp.profile.CompanyContact',
    config: {
        model: 'Personify.model.jsonp.profile.CompanyContact'
    }
});