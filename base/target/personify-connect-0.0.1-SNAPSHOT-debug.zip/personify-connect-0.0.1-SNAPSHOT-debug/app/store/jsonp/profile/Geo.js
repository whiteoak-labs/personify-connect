Ext.define('Personify.store.jsonp.profile.Geo', {
    extend: 'Personify.store.base.profile.Geo',
    requires: 'Personify.model.jsonp.profile.Geo',
    config: {
        model: 'Personify.model.jsonp.profile.Geo'
    }
});