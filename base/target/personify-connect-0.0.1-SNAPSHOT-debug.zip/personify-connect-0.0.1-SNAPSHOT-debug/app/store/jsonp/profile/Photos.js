Ext.define('Personify.store.jsonp.profile.Photos', {
    extend: 'Personify.store.base.profile.Photos',
    requires: 'Personify.model.jsonp.profile.Photos',
    config: {
        model: 'Personify.model.jsonp.profile.Photos'
    }
});