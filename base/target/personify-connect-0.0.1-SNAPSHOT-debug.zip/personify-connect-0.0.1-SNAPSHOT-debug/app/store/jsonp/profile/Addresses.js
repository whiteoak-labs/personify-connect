Ext.define('Personify.store.jsonp.profile.Addresses', {
    extend: 'Personify.store.base.profile.Addresses',
    requires: 'Personify.model.jsonp.profile.Addresses',
    config: {
        model: 'Personify.model.jsonp.profile.Addresses'
    }
});