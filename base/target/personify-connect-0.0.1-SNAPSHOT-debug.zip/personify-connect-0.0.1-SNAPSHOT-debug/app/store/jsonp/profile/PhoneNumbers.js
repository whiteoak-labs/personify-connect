Ext.define('Personify.store.jsonp.profile.PhoneNumbers', {
    extend: 'Personify.store.base.profile.PhoneNumbers',
    requires: 'Personify.model.jsonp.profile.PhoneNumbers',
    config: {
        model: 'Personify.model.jsonp.profile.PhoneNumbers'
    }
});