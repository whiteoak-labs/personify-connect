Ext.define('Personify.store.jsonp.profile.Emails', {
    extend: 'Personify.store.base.profile.Emails',
    requires: 'Personify.model.jsonp.profile.Emails',
    config: {
        model: 'Personify.model.jsonp.profile.Emails'
    }
});