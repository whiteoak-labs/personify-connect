Ext.define('Personify.controller.Participation', {
    extend: 'Personify.base.Controller',
    control : {
        
    },
    onGetData: function(){
    },

    init : function() {
        this.onGetData();
    }
});
