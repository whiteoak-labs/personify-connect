Ext.define('Personify.controller.Agenda', {
    extend: 'Personify.base.Controller',
    control : {
        
    }
});
