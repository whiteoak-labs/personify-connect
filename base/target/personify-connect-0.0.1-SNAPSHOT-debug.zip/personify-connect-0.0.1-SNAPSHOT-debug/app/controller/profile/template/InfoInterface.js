Ext.define('Personify.controller.profile.template.InfoInterface', {
    extend: 'Personify.base.Controller',
    
    control: {
        
    },
    
    config: {
    },
    
    setRecord: function(record) {
        
    },
    
    updateEditMode: function(value, countryListStore) {
    },
    
    validateData: function() {
        
    },
    updateParams: function(params) {
        
    },
    
    setBioInfo: function(record) {
        
    },
    setPresenterRecord: function(presenter) {
        
    }
})