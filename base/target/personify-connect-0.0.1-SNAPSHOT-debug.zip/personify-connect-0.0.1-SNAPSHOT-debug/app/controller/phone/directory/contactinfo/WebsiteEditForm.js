Ext.define('Personify.controller.phone.directory.contactinfo.WebsiteEditForm', {
    extend: 'Personify.controller.profile.WebsiteEditForm'
});