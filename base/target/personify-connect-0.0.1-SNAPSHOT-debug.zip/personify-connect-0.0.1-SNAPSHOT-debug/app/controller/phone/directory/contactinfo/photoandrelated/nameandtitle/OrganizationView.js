Ext.define('Personify.controller.phone.directory.contactinfo.photoandrelated.nameandtitle.OrganizationView', {
    extend: 'Personify.controller.profile.OrganizationView',
    
    control: {
        organizationName: {
            
        }
    }
    
//    setPresenterRecord: function(presenter) {
//        if(presenter && presenter.get('employer') && presenter.get('employer') != '') {
//            this.getOrganizationName().setHtml(presenter.get('employer'));
//        } else {
//            this.getOrganizationName().setHtml('');
//        }
//    }
})