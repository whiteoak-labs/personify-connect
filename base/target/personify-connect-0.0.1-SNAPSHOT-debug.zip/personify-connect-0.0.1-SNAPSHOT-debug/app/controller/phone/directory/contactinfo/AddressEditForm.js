Ext.define('Personify.controller.phone.directory.contactinfo.AddressEditForm', {
    extend: 'Personify.controller.profile.AddressEditForm'
});