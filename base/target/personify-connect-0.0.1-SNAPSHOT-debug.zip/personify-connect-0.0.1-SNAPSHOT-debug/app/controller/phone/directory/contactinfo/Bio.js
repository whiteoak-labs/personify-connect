Ext.define('Personify.controller.phone.directory.contactinfo.Bio', {
    extend: 'Personify.controller.profile.Bio',
    
    control: {
        biographyText: {}
    }
})