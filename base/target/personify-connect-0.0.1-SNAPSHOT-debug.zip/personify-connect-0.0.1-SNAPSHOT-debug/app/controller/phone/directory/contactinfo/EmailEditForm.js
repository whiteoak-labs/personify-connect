Ext.define('Personify.controller.phone.directory.contactinfo.EmailEditForm', {
    extend: 'Personify.controller.profile.EmailEditForm'
});