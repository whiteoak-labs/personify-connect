Ext.define('Personify.controller.phone.purchasehistory.PurchaseHistoryList', {
    extend: 'Personify.base.Controller',
    
    control: {
    }
});
