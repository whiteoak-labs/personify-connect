Ext.define('Personify.controller.Contact', {
    extend: 'Personify.base.Controller',
    control : {
        
    },
    onGetData: function() {
    },
    
    init : function() {
        this.onGetData();
    }
});
