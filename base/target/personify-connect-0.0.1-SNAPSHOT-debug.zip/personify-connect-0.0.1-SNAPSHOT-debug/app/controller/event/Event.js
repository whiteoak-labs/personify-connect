Ext.define('Personify.controller.event.Event', {
    extend: 'Personify.base.Controller',
    control: {
        
    },
    init: function() {
        
    }
});
