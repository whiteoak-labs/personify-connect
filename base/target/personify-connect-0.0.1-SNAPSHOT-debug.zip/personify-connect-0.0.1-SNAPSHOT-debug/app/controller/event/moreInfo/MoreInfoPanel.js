Ext.define('Personify.controller.event.moreInfo.MoreInfoPanel',{
    extend: 'Personify.base.Controller',
    control: {
       
    }//control
    
    
});