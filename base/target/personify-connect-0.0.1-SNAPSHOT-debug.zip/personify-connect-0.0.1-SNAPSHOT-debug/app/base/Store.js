Ext.define('Personify.base.Store', {
    extend: 'Ext.data.Store',
    
    config:{
        dataRequest:null
    }
});
