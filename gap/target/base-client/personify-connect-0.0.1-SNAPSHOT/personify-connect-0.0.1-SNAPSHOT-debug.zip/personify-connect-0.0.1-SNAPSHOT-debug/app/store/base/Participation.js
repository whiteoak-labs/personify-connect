
Ext.define('Personify.store.base.Participation', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Participation'
    ]
});