Ext.define('Personify.store.base.Attendee', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Attendee'
    ]
});