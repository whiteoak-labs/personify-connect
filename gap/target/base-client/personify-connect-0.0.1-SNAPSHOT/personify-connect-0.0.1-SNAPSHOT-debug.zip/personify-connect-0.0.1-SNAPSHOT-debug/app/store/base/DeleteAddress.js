Ext.define('Personify.store.base.DeleteAddress', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Profile'
    ]
});