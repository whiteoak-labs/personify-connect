Ext.define('Personify.store.base.Agenda', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Agenda'
    ]
});