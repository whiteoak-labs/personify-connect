
Ext.define('Personify.store.base.Schedule', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.ICalendar'
    ]
});