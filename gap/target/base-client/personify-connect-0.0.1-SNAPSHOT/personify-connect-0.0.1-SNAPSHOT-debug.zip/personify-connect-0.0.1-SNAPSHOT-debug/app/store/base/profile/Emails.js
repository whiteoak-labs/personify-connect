Ext.define('Personify.store.base.profile.Emails', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.profile.Emails'
});