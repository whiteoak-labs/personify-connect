Ext.define('Personify.store.base.product.ProductClass', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.product.ProductClass'
});