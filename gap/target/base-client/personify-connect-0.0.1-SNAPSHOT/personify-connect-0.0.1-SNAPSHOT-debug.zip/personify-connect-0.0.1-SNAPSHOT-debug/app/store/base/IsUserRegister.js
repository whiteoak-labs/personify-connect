Ext.define('Personify.store.base.IsUserRegister', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.user.IsUserRegister'
    ]
});