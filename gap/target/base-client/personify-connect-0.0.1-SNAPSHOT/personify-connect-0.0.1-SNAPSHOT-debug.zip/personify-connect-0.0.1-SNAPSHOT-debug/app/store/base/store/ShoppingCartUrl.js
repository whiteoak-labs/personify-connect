Ext.define('Personify.store.base.store.ShoppingCartUrl', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.jsonp.store.ShoppingCartUrl'
    ]
});
