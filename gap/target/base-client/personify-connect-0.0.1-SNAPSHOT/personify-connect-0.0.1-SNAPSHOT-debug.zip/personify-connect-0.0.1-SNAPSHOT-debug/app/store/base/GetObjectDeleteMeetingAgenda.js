Ext.define('Personify.store.base.GetObjectDeleteMeetingAgenda', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.CustomerMeetingAgenda'
    ]
});