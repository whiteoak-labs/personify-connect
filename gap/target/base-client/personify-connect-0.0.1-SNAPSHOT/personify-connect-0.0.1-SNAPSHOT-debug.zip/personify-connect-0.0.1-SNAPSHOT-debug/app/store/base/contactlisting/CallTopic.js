
Ext.define('Personify.store.base.contactlisting.CallTopic', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.contactlisting.CallTopic'
    ]
});