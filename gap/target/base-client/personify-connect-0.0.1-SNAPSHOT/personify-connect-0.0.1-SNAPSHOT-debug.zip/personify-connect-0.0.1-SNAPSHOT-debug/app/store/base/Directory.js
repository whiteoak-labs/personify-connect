Ext.define('Personify.store.base.Directory', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Directory'
    ]
});