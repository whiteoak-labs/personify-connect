
Ext.define('Personify.store.base.Session', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Session'
    ]
});