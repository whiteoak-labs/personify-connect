Ext.define('Personify.store.base.product.ProductList', {
    extend: 'Personify.base.Store',
    requires: 'Personify.model.base.product.ProductList'
});