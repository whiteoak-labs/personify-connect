
Ext.define('Personify.store.base.User', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.User'
    ]
});