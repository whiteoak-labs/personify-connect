Ext.define('Personify.store.base.Presenter', {
    extend: 'Personify.base.Store',
    requires: [
        'Personify.model.base.Presenter'
    ]
});