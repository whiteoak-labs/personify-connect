Ext.define('Personify.store.jsonp.profile.Roles', {
    extend: 'Personify.store.base.profile.Roles',
    requires: 'Personify.model.jsonp.profile.Roles',
    config: {
        model: 'Personify.model.jsonp.profile.Roles'
    }
});