Ext.define('Personify.view.profile.ChangePassword', {
    extend: 'Ext.Container',
    alias: 'widget.changepasswordview',
    controller: 'Personify.controller.profile.ChangePassword',
    requires: 'Personify.controller.profile.ChangePassword',

    config: {
        cls:'participation-history',
        html: 'Change Password - Comming soon'
    }
});
