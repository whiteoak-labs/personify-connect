Ext.define('Personify.controller.profile.ChangePassword', {
    extend: 'Personify.base.Controller'
});
