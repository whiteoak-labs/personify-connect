Ext.define('Personify.controller.phone.relationship.RelationshipList', {
    extend: 'Personify.base.Controller',
    
    control: {
    }
});
