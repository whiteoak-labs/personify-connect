Ext.define('Personify.controller.profile.contactinfo.NameAndTitle', {
    extend: 'Personify.controller.profile.template.InfoTemplate',
    
    control: {
        
    },
    
    setRecord: function(record) {
        //get name profile from record and set to view name and title inside
    }
})