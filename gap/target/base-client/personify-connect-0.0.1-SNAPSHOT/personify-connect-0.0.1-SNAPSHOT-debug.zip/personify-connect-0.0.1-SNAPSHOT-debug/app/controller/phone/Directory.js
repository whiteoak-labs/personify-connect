Ext.define('Personify.controller.phone.Directory', {
    extend: 'Personify.controller.directory.Directory',
    
    control: {
        
    }
});