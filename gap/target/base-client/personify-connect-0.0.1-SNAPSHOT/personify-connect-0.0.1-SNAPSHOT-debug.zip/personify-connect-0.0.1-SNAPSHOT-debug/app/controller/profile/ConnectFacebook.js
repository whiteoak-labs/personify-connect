Ext.define('Personify.controller.profile.ConnectFacebook', {
    extend: 'Personify.base.Controller',
    
    control: {
        
    },
    
    loadContactData: function() {
        
    }
});
