Ext.define('Personify.controller.phone.directory.contactinfo.ListInfoTemplate', {
    extend: 'Personify.base.Controller',
    
    control: {
        view: {
            
        }
    },
    
    init: function() {
    }
})