Ext.define('Personify.controller.event.complexevent.ComplexEventMenu',{
    extend: 'Personify.base.Controller',
    control:{
    	
    }
});