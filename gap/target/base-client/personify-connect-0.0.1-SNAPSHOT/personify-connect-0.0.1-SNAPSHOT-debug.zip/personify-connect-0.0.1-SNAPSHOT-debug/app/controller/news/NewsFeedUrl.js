Ext.define('Personify.controller.news.NewsFeedUrl', {
    extend: 'Personify.base.Controller'
});
