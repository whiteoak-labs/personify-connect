Ext.define('Personify.base.Profile', {
    extend: 'Ext.app.Profile'
});
